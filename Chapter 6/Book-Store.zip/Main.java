

class Main{

    public static void main(String[] args){

        Book book1 = new Book("Book Title", "Author Name", "Publisher", 19283);


        book1.printData();

    }



}
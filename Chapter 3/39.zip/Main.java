class Main {
  public static void main(String[] args) {
    
      int x;
      int y = 100;
      
      if(y == 100){

        x = 1;

      }else{

        x = 0;
        
      }


  }
}
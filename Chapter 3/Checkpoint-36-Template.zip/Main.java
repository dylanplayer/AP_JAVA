class Main {
  public static void main(String[] args) {
/*3.20 Assume the variable name references a String object. Write an if statement that displays “Do I know you?” if the String object contains “Timothy”.*/

/*3.21 Assume the variables name1 and name2 reference two different String objects, containing different strings. Write code that displays the strings referenced by these
variables in alphabetical order. */

/*3.22 Modify the statement you wrote in response to Checkpoint 3.20 so it performs a
case-insensitive comparison.;*/


  }
}
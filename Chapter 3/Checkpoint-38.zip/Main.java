class Main {
public static void main(String[] args) {
/*3.23 Rewrite the following if-else statements as statements that use the conditional operator.*/
//a)
 if (x > y)
z = 1;
else
z = 20;
//b)
if (temp > 45)
population = base * 10;
else
population = base * 2;
//c)
if (hours > 40)
wages *= 1.5;
else
wages *= 1;
//d)
if (result >= 0)
System.out.println("The result is positive.");
else
System.out.println("The result is negative.");
  }
}
class Main {
  public static void main(String[] args) {
    
		for(int i = 100; i > 0; i -= 5){

			System.out.println(i);

		}

		int x = 100;
		do{

			x -= 5;
			System.out.println(x);


		}while(x > 0);

		int j = 100;
		while(j > 0){

			j -= 5;
			System.out.println(j);


		}


  }
}
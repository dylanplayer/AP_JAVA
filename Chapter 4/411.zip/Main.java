class Main {
  public static void main(String[] args) {
		

		for(int i = 49; i > 0; i -= 2){

			System.out.println(i);

		}


  }
}
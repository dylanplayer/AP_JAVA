class Main {

  public static void main(String[] args) {
    
		Exam myExam = new Exam(30, 10, 20, 30);

		System.out.println("Exam Score: " + myExam.getScore());


  }
	
}

class Main {
  
	public static void main(String[] args) {
    
		ClassD myClass = new ClassD();
		myClass.setQ(10);
		myClass.setR(10);

		System.out.println(myClass.calc());

  }

}
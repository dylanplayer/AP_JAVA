

public abstract class ClassB{

	private int m;
	protected int n;

	public void setM(int m){

		this.m = m;

	}

	public void setN(int n){

		this.n = n;

	}

	public int getM(){

		return m;

	}

	public double getN(){

		return n;

	}

	public abstract double calc();





}
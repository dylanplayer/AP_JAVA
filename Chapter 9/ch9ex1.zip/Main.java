

class Main {


  public static void main(String[] args) {

		System.out.println("--------------------------");

		Poodle poodle1 = new Poodle("Dave", 3.5, "Male", "toyPoodle");

		Poodle.printPoodle(poodle1);

		System.out.println("--------------------------");

		Poodle poodle2 = new Poodle("Steve", 145.67, "Male", "Poodle");

		Poodle.printPoodle(poodle2);

		System.out.println("--------------------------");


  }
}
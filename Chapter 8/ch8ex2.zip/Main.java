

class Main {

  public static void main(String[] args) {

		Thing one = new Thing();
		Thing two = new Thing();
		Thing three = new Thing();

		Thing.putThing(2);

  }

}
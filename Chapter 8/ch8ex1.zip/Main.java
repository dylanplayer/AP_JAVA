

class Main {

  public static void main(String[] args) {

		System.out.printf("\nRectangle: %.2f\n", Area.getArea(5, 10));
		System.out.printf("Circle: %.2f\n", Area.getArea(13.5));
		System.out.printf("Cilinder: %.2f\n", Area.getArea(5.0, 10.0));


  }

}
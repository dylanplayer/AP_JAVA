class Main{

    enum Pet{DOG, CAT, BIRD, HAMSTERS};

    public static void main(String[] args){

        Pet myDog = Pet.DOG;

        System.out.println(myDog);

    }

}


class Main{

    public static void main(String[] args){

        EmployeeStuff stuff = new EmployeeStuff(100, 25, 14, 1000);

        double[] randomArr = new double[]{1.7, 6.4, 8.9, 3.1, 9.2};

        System.out.println(randomArr.length);

    }




}